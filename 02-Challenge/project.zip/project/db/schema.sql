DROP DATABASE IF EXISTS rawg_reviews_db;
CREATE DATABASE rawg_reviews_db;